$Title A Quadratic-Linear Program for Mean-Variance Portfolio Analysis
$Ontext
* Program by Seung-Rae Kim
These are mean-variance portfolio selection models with two alternatives
formulations in GAMS: (1) maximizing expected mean return, net of
variance costs, & (2) minimizing the overall variance costs of portfolio.
$Offtext

 Set i equities /equity1, equity2, equity3/;
 Alias (i,j) ;
 Scalar theta desired minimum mean-return on portfolio (%) / 10 /
        beta subjective weight on returns variance of equities / 2 /;

Parameters mu(i) mean annual returns on equities (%)
 / equity1  8
   equity2 12
   equity3 15 / ;

 Table sigma(i,j) covariance matrix of returns on equities
         equity1 equity2 equity3
 equity1    6     -5       4
 equity2   -5     17     -11
 equity3    4    -11      24 ;

 Variables
 x(i) fraction of portfolio invested in equity i in formulation 1
 y(i) fraction of portfolio invested in equity i in formulation 2
 criterion1 expected mean return on portfolio, net of variance cost
 criterion2 variance-augmented total risk cost of portfolio ;

 Positive Variable x, y ;

 Equations dcri1 definition of criterion1

 dcri2 definition of criterion2
 xsum fractions x(i) must add to 1.0
 dmu desired minimum mean-return on portfolio y(i)
 ysum fractions y(i) must add to 1.0 ;
 dcri1.. criterion1 =e= sum(i, mu(i)*x(i))-.5*sum(i, x(i)*sum(j, beta*sigma(i,j)*x(j))) ;
 dcri2.. criterion2 =e= .5*sum(i, y(i)*sum(j, beta*sigma(i,j)*y(j))) ;
 xsum.. sum(i, x(i)) =e= 1.0 ;
 dmu.. sum(i, mu(i)*y(i)) =g= theta ;
 ysum.. sum(i, y(i)) =e= 1.0 ;

 Model portfolio1 / dcri1, xsum / ;
 Model portfolio2 / dcri2, dmu, ysum / ;

 Solve portfolio1 using nlp maximizing criterion1;
 Solve portfolio2 using nlp minimizing criterion2;
