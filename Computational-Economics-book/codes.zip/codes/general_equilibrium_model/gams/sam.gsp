{
    "file": "sam.gms",
    "name": "sam",
    "nodes": [
        {
            "codecMib": 106,
            "file": "sam.gms",
            "name": "sam.gms",
            "type": "gms"
        },
        {
            "codecMib": 106,
            "file": "sam.lst",
            "name": "sam.lst",
            "type": "lst"
        }
    ],
    "options": [
        ""
    ],
    "path": ".",
    "pf": "",
    "workDir": "."
}
