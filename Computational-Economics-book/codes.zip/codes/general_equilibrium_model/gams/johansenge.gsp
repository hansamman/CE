{
    "file": "johansenge.gms",
    "name": "johansenge",
    "nodes": [
        {
            "codecMib": 106,
            "file": "johansenge.gms",
            "name": "johansenge.gms",
            "type": "gms"
        },
        {
            "codecMib": 106,
            "file": "johansenge.lst",
            "name": "johansenge.lst",
            "type": "lst"
        }
    ],
    "options": [
        ""
    ],
    "path": ".",
    "pf": "",
    "workDir": "."
}
