{
    "file": "prodpri.gms",
    "name": "prodpri",
    "nodes": [
        {
            "codecMib": 106,
            "file": "prodpri.gms",
            "name": "prodpri.gms",
            "type": "gms"
        },
        {
            "codecMib": 106,
            "file": "prodpri.lst",
            "name": "prodpri.lst",
            "type": "lst"
        }
    ],
    "options": [
        ""
    ],
    "path": ".",
    "pf": "",
    "workDir": "."
}
