$TITLE JohansenGE 
* Developed by Ruben Mercado
 
SCALARS 
a labor share / 0.7 / 
 
VARIABLES 
qs good supply 
qd good demand 
ld labor demand 
ls labor supply 
kd capital demand 
ks capital supply 
p price 
w wage 
r profit 
y income 
j  performance index; 
 
EQUATIONS 
eqs good supply equation (production funcion) 
eqd good demand equation 
eld labor demand equation 
els labor supply equation 
ekd capital demand equation 
eks capital supply equation 
ey  income equation 
eml labor market clearing 
emk capital market clearing 
jd performance index definition; 
 
jd..       j =E= 0; 
 
eqs..     qs =E= ld * a + kd *(1-a); 
eld..     ld =E= qs + p - w; 
els..     ls =E= 0; 
eml..     ld =E= ls; 
ekd..     kd =E= qs + p - r; 
eks..     ks =E= 0; 
emk..     kd =E= ks; 
ey..       y =E= (0.7)*(w + ld)+ 0.3 *(r + kd); 
eqd..     qd =E= y - p; 
 
*numeraire 
p.fx = 0; 
 
MODEL JOHANSENGE /all/; 
SOLVE JOHANSENGE MAXIMIZING J USING LP; 
DISPLAY qs.l, qd.l, ld.l, ls.l, kd.l, ks.l, p.l, w.l, r.l, y.l; 
