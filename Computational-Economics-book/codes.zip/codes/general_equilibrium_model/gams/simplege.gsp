{
    "file": "simplege.gms",
    "name": "simplege",
    "nodes": [
        {
            "codecMib": 106,
            "file": "simplege.gms",
            "name": "simplege.gms",
            "type": "gms"
        },
        {
            "codecMib": 106,
            "file": "simplege.lst",
            "name": "simplege.lst",
            "type": "lst"
        }
    ],
    "options": [
        ""
    ],
    "path": ".",
    "pf": "",
    "workDir": "."
}
