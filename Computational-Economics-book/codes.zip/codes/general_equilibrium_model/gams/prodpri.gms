$TITLE ProdPri 
* Production Prices Model 
* Developed by Ruben Mercado

* option NLP=MINOS;
* NOTE TO PC USERS: Remove the asterisk from the above line.
* i.e., on PC this code must be run with the option NLP=MINOS
 
SCALARS 
L1 /0.2/ 
L2 /0.5/ 
L3 /0.3/; 
 
VARIABLES 
p1 
p2 
p3 
w 
r 
j  performance index; 
 
EQUATIONS 
eqp1 
eqp2 
eqp3 
jd performance index definition; 
 
jd..    j =E= 0; 
eqp1.. (0.3*p1 + 0.1*p2 + 0.4*p3) * (1+r) + L1 * w =E= p1; 
eqp2.. (0.2*p1 + 0.4*p2 + 0.1*p3) * (1+r) + L2 * w =E= p2; 
eqp3.. (0.2*p1 + 0.5*p2 + 0.2*p3) * (1+r) + L3 * w =E= p3; 
 
r.fx = 0; 
p1.fx = 1; 
 
MODEL PP1 /all/; 
SOLVE PP1 MAXIMIZING J USING NLP; 
DISPLAY p1.l, p2.l, p3.l, w.l, r.l;
