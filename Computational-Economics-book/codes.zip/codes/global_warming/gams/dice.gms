$offsymxref offsymlist 
* Explaining the DICE, Cowles Foundation Discussion Paper, January 1991
* The calibration is to a 60-period run for the transversality
*
sets    t               time periods     /1*40/
        tfirst(t)       first period
        tlast(t)        last period

scalars bet     elasticity of marginal utility          /0/
        r       rate of social time preference per year /0.03/
        gl0     growth rate of population per decade    /0.223/
        dlab    decline rate of population growth per decade    /0.195/
        deltam  removal rate carbon per decade  /0.0833/
        ga0     initial growth rate for technology per decade   /0.15/
        dela    decline rate of technological change per year   /0.11/
        sig0    co2-equivalent emissions-gnp ratio      /0.519/
        gsigma  growth of sigma per decade      / - 0.1168 /
        dk      depreciation rate on capital per year /0.10/
        gama    capital elasticity in production function       /0.25/
        m0      co2-equivalent concentrations 1965 billions t c /677/
        tl0     lower stratum temperature (c) 1965      /0.10/
        t0      atmospheric temperature (c) 1965        /0.2/
        atret   marginal atmosphere retension rate      /0.64/
        q0      1965 world gross output trillion 89 US$    /8.519/
        ll0     1965 world population million   /3369/
        k0      1965 value capital trillion 1989 US$    /16.03/
        c1      climate-equation coefficient for upper level    /0.226/
        lam     climate feedback factor /1.41/
        c3      transfer coefficient upper to lower stratum     /0.440/
        c4      transfer coefficient for lower level    /0.02/
        a0      initial level of total factor productivity      /0.00963/
        a1      damage coefficient for co2 doubling (fraction GWP)      /0.0133/
        b1      intercept control cost function /0.0686/
        b2      exponent of control cost function       /2.887/
        phik    transversality coeff capital ($ per unit)        /140/
        phim    transversality coeff carbon ($ per unit)  / - 9.0 /
        phite   transversality coeff temperature ($ per unit)  / - 7000 /

parameters      l(t)    level of population and labour
                al(t)   level of total factor productivity
                sigma(t)        co2-equvalent-emissions output ratio
                rr(t)   discount factor
                ga(t)   growth rate of productivity from 0 to t 
                forcoth(t)      exogenous forcing for other greenhouse gases
                gl(t)   growth rate of labour 0 to t
                gsig(t) cumulative improvement of energy-efficincy
                dum(t)  dummay variable 0 except last period ;

        tfirst(t) = yes$(ord(t) eq 1);
        tlast(t)  = yes$(ord(t) eq card(t));
        display tfirst, tlast;

        gl(t) = (gl0/dlab)*(1-exp(-dlab*(ord(t)-1)));
        l(t)  = ll0*exp(gl(t));
        ga(t) = (ga0/dela)*(1-exp(-dela*(ord(t)-1)));

        al(t) = a0*exp(ga(t));
        gsig(t) = (gsigma/dela)*(1-exp(-dela*(ord(t)-1)));
        sigma(t) = sig0*exp(gsig(t));

        dum(t) = 1$(ord(t) eq card(t));
        rr(t)  = (1+r)**(10*(1-ord(t)));

        forcoth(t)  =  1.42;
        forcoth(t)$(ord(t) lt 15) = 0.2604 + 0.125*ord(t) - 0.0034*ord(t)**2;

variables       miu(t)  emission control rate GHGs
                forc(t) radiative forcing, W per m2
                te(t)   temperature, atmosphere C
                tl(t)   temperature, lower ocean C
                m(t)    co2 equivalent concentration bill t
                e(t)    co2 equivalent emissions bill t
                c(t)    consumption trillion US$
                k(t)    capital stock trillion US$
                cpc(t)  per-capita consumption 1000s US$
                pcy(t)  per-capita income 1000s US$
                i(t)    investment trillion US$
                s(t)    savings rate as fraction of GWP
                ri(t)   real interest rate per annum
                trans(t)        transversality variable last period
                y(t)    output

                utility;

positive variables miu, e, te, m, y, c, k, i;

equations       util    objective function
                yy(t)   output equation
                cc(t)   consumption equation
                kk(t)   capital balance equation
                kk0(t)  initial condition for k
                kc(t)   terminal condition for k
                cpce(t) per-capita consumption definition
                pcye(t) per-capita income definition
                ee(t)   emissions precess
                seq(t)  savings rate equation
                rieq(t) interest rate equation
                force(t)  radiative forcing equation
                mm(t)   co2 distribution equation
                mm0(t)  initial condition for m
                tte(t)  temperature-climate equation for atmosphere
                tte0(t)  initial condition for atmospheric temperature
                tle(t)  temperature-climate equation for lower oceans
                transe(t) transversality condition
                tle0(t) initial condition for lower ocean ;

* Equations of the model

kk(t).. k(t+1) =l= (1-dk)**10*k(t) + 10*i(t) ;
kk0(tfirst)..   k(tfirst) =e= k0 ;
kc(tlast)..     r*k(tlast) =l= i(tlast) ;     

ee(t).. e(t) =g= 10*sigma(t)*(1 - miu(t))*al(t)*l(t)**(1 - gama)*k(t)**gama ;
force(t)..      forc(t) =e= 4.1*(log(m(t)/590)/log(2)) + forcoth(t) ;
mm0(tfirst)..   m(tfirst) =e= m0 ;
mm(t+1).. m(t+1) =e= 590 + atret*e(t) + (1 - deltam)*(m(t) - 590) ;

tte0(tfirst)..  te(tfirst) =e= t0 ;
tte(t+1)..      te(t+1) =e= te(t)+c1*(forc(t)-lam*te(t)-c3*(te(t)-tl(t))) ;
tle0(tfirst)..  tl(tfirst) =e= tl0 ;
tle(t+1)..      tl(t+1) =e= tl(t) + c4*(te(t) - tl(t));

yy(t).. y(t) =e= al(t)*l(t)**(1-gama)*k(t)**gama*(1-b1*(miu(t)**b2))/(1+(a1/9)*sqr(te(t)));
seq(t)..        s(t) =e= i(t)/(.001+y(t)) ;
rieq(t)..       ri(t) =e= gama*y(t)/k(t) - (1-(1-dk)**10)/10 ;

cc(t).. c(t) =e= y(t) - i(t) ;
cpce(t)..       cpc(t) =e= c(t)*1000/l(t) ;
pcye(t)..       pcy(t) =e= y(t)*1000/l(t) ;

transe(tlast).. trans(tlast) =e= rr(tlast)*(phik*k(tlast)+phim*m(tlast)+phite*te(tlast));

util..  utility =e= sum(t,10*rr(t)*l(t)*log(c(t)/l(t))/0.55+trans(t)*dum(t));

* Upper and lower bounds; general conditions imposed for stability

miu.up(t) = 0.99;
miu.lo(t) = 0.01;
k.lo(t) = 1;
te.up(t) = 20;
m.lo(t) = 600 ;
c.lo(t) = 2;

* Upper and lower bounds for historical constraints

miu.fx('1') = 0.0;
miu.fx('2') = 0.0;
miu.fx('3') = 0.0;

* Solution options

option iterlim = 99999;
option reslim = 99999;
option solprint = off;
option limrow = 0;
option limcol = 0;

model co2 /all/ ;
solve co2 maximising utility using nlp ;

* Display of results

display y.l, c.l, s.l, k.l, miu.l, e.l, m.l, te.l, forc.l, ri.l ;
display cc.m, ee.m, kk.m, mm.m, tte.m, cpc.l, tl.l, pcy.l, i.l ;
display sigma, rr, l, al, dum, forcoth ;


