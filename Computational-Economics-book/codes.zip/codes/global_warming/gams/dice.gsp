{
    "file": "dice.gms",
    "name": "dice",
    "nodes": [
        {
            "codecMib": 106,
            "file": "dice.gms",
            "name": "dice.gms",
            "type": "gms"
        },
        {
            "codecMib": 106,
            "file": "dice.lst",
            "name": "dice.lst",
            "type": "lst"
        }
    ],
    "options": [
        ""
    ],
    "path": ".",
    "pf": "",
    "workDir": "."
}
