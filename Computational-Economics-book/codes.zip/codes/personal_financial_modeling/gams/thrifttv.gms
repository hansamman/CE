*Student Finance Model in GAMS
*By Genevieve Solomon
*This version also has some modifications by David Kendrick

*If you want a larger number of years please note that
*this may not run in the demo version of GAMS
*you could choose to have 2 or 3 years in each period instead

*If you get the error 'A free variable exceeds allowable range'
*you could renormalize the numbers in terms of 'thousands of dollars'


Sets    n states  / Sb, Se, Sc, Scc, Ssl /
        m controls  / Xbe, Xbc, Xbcc, Xbsl, Xec, Xecc, Xesl, Xcacc, Xcsl, Xccsl /
        k exogenous  / Wa, Le, Sh /
        t horizon  / 2000, 2001, 2002, 2003, 2004 /

        tu(t) control horizon
        ti(t) initial period
        tz(t) terminal period ;



Alias (n,np), (m,mp) ;

tu(t) = yes$(ord(t) lt card(t));
ti(t) = yes$(ord(t) eq 1);
tz(t) = not tu(t);
Display t, ti, tz, tu;

Table a(n,np)  state vector matrix

        Sb     Se     Sc      Scc     Ssl
Sb      1.05
Se             1.10
Sc                    1.01
Scc                           1.13
Ssl                                   1.04

Table b(n,m)  control vector matrix

       Xbe      Xbc     Xbcc      Xbsl      Xec      Xecc      Xesl
Sb      -1      -1       -1        -1
Se       1                                   -1        -1       -1
Sc               1                            1
Scc                      -1                            -1
Ssl                                -1                           -1

+
       Xcacc     Xcsl     Xccsl
Sb
Se
Sc      -1        -1
Scc     -1                  1
Ssl               -1       -1


Table c(n,k)  exogenous vector matrix

        Wa      Le      Sh
Sb
Se
Sc      1       -1       1
Scc
Ssl

Table w(n,np)  state vector matrix penalty matrix

        Sb     Se     Sc      Scc     Ssl
Sb     100
Se             100
Sc                    400
Scc                           200
Ssl                                   0


Table wn(n,np)  terminal state vector matrix penalty matrix

        Sb     Se     Sc      Scc     Ssl
Sb     200
Se             200
Sc                    800
Scc                           200
Ssl                                   1

Table lambda(m,mp) lambda matrix

       Xbe      Xbc     Xbcc      Xbsl      Xec      Xecc      Xesl
Xbe    20
Xbc              1
Xbcc                     20
Xbsl                               20
Xec                                          20
Xecc                                                  20
Xesl                                                             20

+
         Xcacc     Xcsl     Xccsl
Xcacc      1
Xcsl                 1
Xccsl                        20


Table xtilde(n,t)  state vector desired paths

      2000        2001         2002        2003        2004
Sb
Se
Sc    1000        1000         1000        1000        1000
Scc   2000        2000         2000        2000        2000
Ssl


Table utilde(m,t)  control vector desired paths

          2000     2001     2002     2003
Xbe
Xbc
Xbcc
Xbsl
Xec
Xecc
Xesl
Xcacc
Xcsl
Xccsl


Parameter
        xinit(n)   initial value   /
             Sb  4000
             Se     0
             Sc  1000
             Scc    0
             Ssl    0 /

Table z(k,t)  exogenous variables

      2000        2001         2002        2003        2004
Wa   15000       15000        15000       15000       15000
Le   20000       20000        20000       20000       20000
Sh       0           0            0           0           0



Variables               u(m,t)    control variable
                        j         criterion ;

Positive Variables      x(n,t)   state variable ;


Equations       criterion       criterion definition
                stateq(n,t)     state equation ;

criterion..

j =e= .5*sum( (tz,n,np),(x(n,tz) - xtilde(n,tz))*wn(n,np)*(x(np,tz) - xtilde(np,tz)) ) +
      .5*sum( (tu,n,np),(x(n,tu) - xtilde(n,tu))*w(n,np)*(x(np,tu) - xtilde(np,tu)) ) +
      .5*sum( (tu,m,mp),(u(m,tu) - utilde(m,tu))*lambda(m,mp)*(u(mp,tu) - utilde(mp,tu)) ) ;

stateq(n,t+1)..
x(n,t+1) =e= sum(np, (a(n,np)*x(np,t))) + sum(m, (b(n,m)*u(m,t))) + sum(k,(c(n,k)*z(k,t)));



Model track /all/;

x.fx(n,ti) = xinit(n);

Solve track minimizing j using nlp;


Display x.l, u.l;
