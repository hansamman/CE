
$TITLE   htsim:   HALL-TAYLOR SIMULATION
* Developed by Ruben Mercado

OPTION SYSOUT = OFF;
OPTION LIMROW = 7;
OPTION LIMCOL = 0;
OPTION SOLPRINT = OFF;
$OFFSYMXREF OFFSYMLIST
***********************************************************************
* SECTION 1 :  DEFINITION OF PARAMETER VALUES FOR THE ORIGINAL
*                          NONLINEAR  HALL-TAYLOR MODEL
***********************************************************************
SCALARS
a       minimum consumption              / 220 /
b       marg prop to consume             / 0.7754 /
d       interest elast of invest.        / 2000 /
ee      maximum  investment              / 1000 /
f       coeff. on excess aggr dem.       / 0.8 /
gg      maximum net exports              / 600 /
h       interest elast  of mon  dem.     / 1000 /
k       income elast  of money dem.      / 0.1583 /
mm      income elast  of net exp         / 0.1 /
n       real ex  rate elast  of net exp  / 100 /
q       constant                         / 0.75 /
tax     tax rate                         / 0.1875 /
v       constant                         / 5 /
alpha   coeff. on 1 lagged inflation     / 0.4 /
beta    coeff. on 2 lagged inflation     / 0.2 /
mu      elast. of empl. wrt GDP          / 0.33 /  ;

***********************************************************************
*  SECTION 2:     DEFINITION OF TEMPORAL HORIZON FOR SIMILATION
***********************************************************************
* If you change the extension of the horizon, make the necessary
* adjustments in the section of shocks' definition  (Section 3)

SETS  T    EXTENDED HORIZON     / 0*15 /
       T0(T) PERIOD ZERO
       T1(T) PERIOD ONE ;

       T0(T) = YES$(ORD(T) EQ 1);
       T1(T) = YES$(ORD(T) EQ 2);
       DISPLAY T0, T1;
***********************************************************************
* SECTION  3 : DEFINITION OF CHANGES IN POLICY AND EXOGENOUS VARIABLES
***********************************************************************
PARAMETERS
*  definition of policy and exogenous variables (in percentage changes)
Mper(T)        money stock  (in % change)
Gper(T)        Gov. expenditure (in % change)
Ynper(T)       potential GDP (in % change)
Pwper(T)       foreign prices (in % change)
*  definition of policy and exogenous variables (in levels)
M(T)     money stock (in levels)
G(T)     Gov. expenditure (in levels)
Yn(T)    potential  GDP (in levels)
Pw(T)    foreign prices (in levels)  ;
*  default values for policy and exogenous variables
Mper(T) = 0.3 ;   Gper(T) = 0 ;  Ynper(T) = 0 ;  Pwper(T) = 0 ;
M(T) = 900 ;    G(T) = 1200 ;  Yn(T) = 6000 ;  Pw(T) = 1 ;
******************************
* CHANGE IN MONEY SUPPLY
******************************
SETS
TS1(T) periods for shock 1    / 4*15 / ;
Mper(TS1) = 0.0 ;
****************************************
* CHANGE IN GOVERNMENT EXPENDITURE
****************************************
SETS
TS2(T) periods for shock 2    / 4*15 / ;
Gper(TS2) = 0.0;
***********************************************************
*  CHANGE IN POTENTIAL GNP (notice that the natural rate of
*                          unemployment remains the same)
***********************************************************
SETS
TS3(T) periods for shock 3    / 4*15 / ;
Ynper(TS3) = 0.0;
****************************
*  CHANGE IN FOREIGN PRICES
****************************
SETS
TS4(T) periods for shock 4    / 4*15 / ;
Pwper(TS4) = 0.0;
*  Transformation of shocks in % changes into shocks in levels
M(TS1) =   900 * (1 + Mper(TS1)) ;
G(TS2) =  1200 * (1 + Gper(TS2)) ;
Yn(TS3) = 6000 * (1 + Ynper(TS3)) ;
Pw(TS4) =    1 * (1 + Pwper(TS4)) ;


* reporting policy and exogenous variables values
PARAMETER REPORTEX  POLICY AND EXOGENOUS VARIABLES VALUES;
  REPORTEX(T,"Money") = M(T);
  REPORTEX(T,"Gov. Exp.") = G(T);
  REPORTEX(T,"Pot. GDP") = Yn(T);
  REPORTEX(T,"Fgn Price") = Pw(T);

***********************************************************************
* SECTION 4:  COMPUTATION OF SOLUTION
***********************************************************************
PARAMETERS
Un(T)          natural rate of unemployment ;
Un(T) = 0.05 ;

VARIABLES
Y(T)          gdp
Yd(T)         disposable income
C(T)          consumption
I(T)          investment
R(T)          interest rate
P(T)          price level
pi(T)         inflation rate
piex(T)       expected inflation rate
E(T)          nominal exchange rate
X(T)          net exports
Gd(T)         government deficit
U(T)          unemployment rate
J             performance index

EQUATIONS
eq1(T)      gdp identity
eq2(T)      disposable income
eq3(T)      consumption
eq4(T)      investment
eq5(T)      money demand
eq6(T)      expected inflation
eq7(T)      inflation rate
eq8(T)      price level
eq9(T)      real exchange rate
eq10(T)     net exports
eq11(T)     government deficit
eq12(T)     unemployment rate
JD          performance index ;

JD..         J =E= 0 ;
eq1(t+2)..   Y(t+2)   =E=   C(t+2) + I(t+2) + G(t+2) + X(t+2) ;

eq2(t+2)..   Yd(t+2)  =E=    (1 - tax) * Y(t+2) ;

eq3(t+2)..   C(t+2)   =E=    a + b * Yd(t+2) ;

eq4(t+2)..   I(t+2)   =E=    ee - d * R(t+2) ;

eq5(t+2)..   M(t+2) / P(t+2)  =E=   k * Y(t+2) - h * R(t+2) ;

eq6(t+2)..   piex(t+2)=E=    alpha * pi(t+1) + beta * pi(t) ;

eq7(t+2)..   pi(t+2)  =E=    piex(t+2) + f*(Y(t+1)-Yn(t+2))/Yn(t+2) ;

eq8(t+2)..   P(t+2)   =E=    P(t+1) * (1 + pi(t+2)) ;

eq9(t+2)..   E(t+2) * P(t+2) / Pw(t+2)  =E=  q  + v * R(t+2) ;

eq10(t+2)..  X(t+2)   =E=   gg - mm*Y(t+2) - n*(E(t+2)*P(t+2)/Pw(t+2));

eq11(t+2)..  Gd(t+2)  =E=    G(t+2) - tax * Y(t+2) ;
eq12(t+2)..  U(t+2)   =E=    Un(t+2) - mu*(Y(t+2)-Yn(t+2))/Yn(t+2) ;

***********************************************************************
* In what follows, we assign initial variables' values and lower bounds
* WARNING: The order of declaration of assignments is very important
*      Successive assignments to a same variable undo the previous ones
***********************************************************************

*  Guess of initial values for the solution algorithm.
*  Without them, the problem may be declared "infeasible"
*  That is, the algorithm will converge to a solution from some initial
*  positions but not from others
*  This is common in nonlinear problems

 R.L(T+2) = 0.09 ; Y.L(T+2) = 6500 ; E.L(T+2) = 1.2; C.L(T+2) = 4500 ;
 I.L(T+2) = 900 ;  X.L(T+2) = -100 ; Gd.L(T+2) = 75 ; U.L(T+2) = 0.07 ;
 Yd.L(T+2)= 4875 ; pi.L(T+2) = 0.1 ; piex.L(T+2)=0.2 ; P.L(T+2) = 1.1 ;

* lower bound for p, to avoid  division by zero
 P.LO(T+2) = 0.0001 ;

* fixing initial steady-state values for lagged endogenous variables
 P.FX(T1) = 1 ;  pi.FX(T0) = 0 ;  pi.FX(T1) = 0 ; Y.FX(T1) = 6000 ;

MODEL NONLDYN  /eq1, eq2, eq3, eq4, eq5, eq6,
                eq7, eq8, eq9, eq10, eq11, eq12, JD / ;

SOLVE NONLDYN MINIMIZING J USING NLP;

* Reporting solution values
PARAMETER REPORTS SOLUTION VALUES IN LEVELS;
  REPORTS(T,"GDP")          = Y.L(T);
  REPORTS(T,"Inflation")    = pi.L(T);
  REPORTS(T,"Int.Rate")     = R.L(T);
  REPORTS(T,"Exch.Rate")    = E.L(T);
  REPORTS(T,"Gov.Def")      = Gd.L(T);
  REPORTS(T,"Unemploy")     = U.L(T);

* Showing final results
DISPLAY REPORTEX;
DISPLAY REPORTS;
